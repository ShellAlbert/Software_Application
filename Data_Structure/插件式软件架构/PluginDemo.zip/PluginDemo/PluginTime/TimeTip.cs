﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace PluginTime
{
    public partial class TimeTip : Form
    {
        public TimeTip()
        {
            InitializeComponent();
        }

        private void TimeTip_Load(object sender, EventArgs e)
        {
            textBox1.Text = DateTime.Now.ToString();
        }
    }
}
