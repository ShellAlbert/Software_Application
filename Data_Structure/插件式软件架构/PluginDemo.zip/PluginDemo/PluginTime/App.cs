﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using PluginDemo.Interface;
using System.Windows.Forms;
using System.Drawing;

namespace PluginTime
{
    public class App : Iplugin
    {
        public Form MainForm
        {
            get { return new TimeTip(); }
        }



        public Image ModulePicture
        {
            get { return ((System.Drawing.Image)(Pics.index)); }
        }
    }
}
