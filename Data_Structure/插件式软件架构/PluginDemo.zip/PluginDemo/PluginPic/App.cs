﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel.Composition;

namespace PluginPic
{
    [Export(typeof(PluginMain.Interface.Iplugin))]
    public class App:PluginMain.Interface.Iplugin
    {
        public System.Windows.Forms.Form MainForm
        {
            get { return new Picture(); }
        }

        public System.Drawing.Image ModulePicture
        {
            get { return PluginPic.Properties.Resources.index; }
        }
    }
}
