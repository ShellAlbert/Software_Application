﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Drawing;
using PluginDemo.Interface;

namespace PluginDate
{
    public class App : Iplugin
    {
        public Form MainForm
        {
            get { return new DatePicker(); }
        }



        public Image ModulePicture
        {
            get { return ((System.Drawing.Image)(Pics.PosNormal)); }
        }
    }
}
