﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Drawing;

namespace PluginMain.Interface
{
    public interface Iplugin
    {
        //设置加载的主窗体
        Form MainForm
        {
            get;
        }

        //插件显示图片
        Image ModulePicture
        {
            get;
        }
    }
}
