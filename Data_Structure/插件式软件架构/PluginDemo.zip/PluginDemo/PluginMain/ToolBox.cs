﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using PluginMain.Interface;
using System.ComponentModel.Composition;
using System.ComponentModel.Composition.Hosting;

namespace PluginMain
{
    public partial class ToolBox : Form
    {
        public ToolBox()
        {
            InitializeComponent();
            Init();
        }
        private CompositionContainer _container;

        private void Init()
        {
            //An aggregate catalog that combines multiple catalogs
            var catalog = new AggregateCatalog();
            //Adds all the parts found in the same assembly as the Program class
            //catalog.Catalogs.Add(new AssemblyCatalog(typeof(Program).Assembly));
            catalog.Catalogs.Add(new DirectoryCatalog(Application.StartupPath + "\\plugin\\"));
            
            //Create the CompositionContainer with the parts in the catalog
            _container = new CompositionContainer(catalog);

            //Fill the imports of this object
            try
            {
                this._container.ComposeParts(this);
            }
            catch (CompositionException compositionException)
            {
                Console.WriteLine(compositionException.ToString());
            }
        }

        private void ToolBox_Load(object sender, EventArgs e)
        {
            InitPlugin();
        }

        [ImportMany]
        public IEnumerable<Iplugin> plugins;


        public void InitPlugin()
        {
            foreach (Iplugin plugin in plugins)
            {
                InitModule(plugin);
            }
        }


        /// <summary>
        /// 初始化插件，显示在列表中
        /// </summary>
        /// <param name="plugin"></param>
        private void InitModule(Iplugin plugin)
        {
            PictureBox picture = new PictureBox();
            picture.BackColor = System.Drawing.Color.Red;

            picture.Image = plugin.ModulePicture;
            picture.InitialImage = null;
            picture.Dock = DockStyle.Left;

            picture.Size = new System.Drawing.Size(65, 71);
            picture.TabStop = false;
            panel1.Controls.Add(picture);
            //单击时加载插件主界面
            picture.Click += (sender, e) =>
            {
                LoadFrm(plugin.MainForm);
            };
        }

        /// <summary>
        /// 加载插件主界面
        /// </summary>
        /// <param name="frm"></param>
        public void LoadFrm(Form frm)
        {
            frm.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            frm.ShowIcon = false;
            frm.ShowInTaskbar = false;
            frm.BackColor = Color.White;
            //要将是否顶级控件设置为false，否则会报错
            frm.TopLevel = false;
            frm.Dock = DockStyle.Fill;
            TabPage tab = new TabPage(frm.Name);
            tab.Controls.Add(frm);
            tabControl1.TabPages.Add(tab);
            tab.Show();
            frm.Show();
            frm.BringToFront();
            frm.Focus();
        }

       
    }
}
